library(DBI)
library(pool)
library(RODBC)
library(RNetezza)


#' Accesses Neteeza database using RODBC connection
#'
#' @param ODBC_con Character string. Name of the ODBC connection (DSN)
#' @return A connection to a database
#' @export
#' @examples
#' library(pool)
#' library(RNetezza)
#' ODBC_con = "Netezza1"
#' pool <- nz_ODBC_pool(ODBC_con)
#' query <- paste("select * from PRD_WHSEVIEW.ADMIN.DM_CUST_MO_SHPMT_ACTVTY limit 10")
#' df <- dbGetQuery(pool, query)
nz_ODBC_pool <- function(ODBC_con) {
  pool <- dbPool(
    drv = RNetezza::Netezza(),
    dsn = ODBC_con
  )
}


#' Accesses Neteeza database using RODBC connection without pooling closing statement included
#'
#' @param ODBC_con Character string. Name of the ODBC connection
#' @param query A variable representing inquiry into the database using the SELECT statement
#' @return Dataframe with inqured variables and values
#' @export
#' @examples
#' query <- paste("select * from PRD_WHSEVIEW.ADMIN.DM_CUST_MO_SHPMT_ACTVTY limit 10")
#' df <- execute_ODBC_sql("Netezza1", query)
execute_ODBC_sql <- function(ODBC_con = "bdname", query) {
  ODBC_NZ <- odbcConnect(ODBC_con)
  data <-  sqlQuery(ODBC_NZ, query, believeNRows=FALSE)
  odbcClose(ODBC_NZ)
  return(data)
}
