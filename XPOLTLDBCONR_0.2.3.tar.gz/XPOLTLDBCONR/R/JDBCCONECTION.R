library(DBI)
library(pool)
library(RJDBC)

#' Accesses Neteeza database using JDBC connection
#'
#' @param Db_driver Loads JDBC driver for desired Database.
#' @param Jdbc_path Path to the driver's JAR file (for shiny server use: "/usr/local/nz/lib/nzjdbc3.jar")
#' @param JDBC_con  Path of the Data Source url including user name and password
#' @return A connection to a database
#' @export
#' @examples
#' library(pool)
#' library(RJDBC)
#' pool <- nz_JDBC_pool(Db_driver = "org.netezza.Driver", Jdbc_path = "C://JDBC//nzjdbc.jar", JDBC_con = "jdbc:netezza//npsdwh.con-way.com:5480/prd_whseview;user=user.name;password=password")
#' query <- paste("select * from PRD_WHSEVIEW.ADMIN.DM_CUST_MO_SHPMT_ACTVTY limit 10")
#' df <- dbGetQuery(pool, query)
nz_JDBC_pool <- function(Db_driver = "org.netezza.Driver", Jdbc_path = "C://JDBC//nzjdbc.jar", JDBC_con = "jdbc:netezza//npsdwh.con-way.com:5480/prd_whseview;user=user.name;password=pw131216") {
  pool <- dbPool(
    drv = JDBC(Db_driver, Jdbc_path),
    url = JDBC_con
  )
}


#' Accesses Neteeza database using JDBC connection without pooling closing statement included
#'
#' @param Db_driver Loads JDBC driver for desired Database.
#' @param Jdbc_path Path to the driver's JAR file (for shiny server use: "/usr/local/nz/lib/nzjdbc3.jar")
#' @param JDBC_con  Path of the Data Source name (DSN)
#' @param user_name User ID associated with accesing a database
#' @param PW Password associated with the user ID
#' @param query A variable representing inquiry into the database using the SELECT statement
#' @return Dataframe with  desired variables and values
#' @export
#' @examples
#' Db_driver = "org.netezza.Driver"
#' Jdbc_path = "C://JDBC//nzjdbc.jar"
#' JDBC_con = "jdbc:netezza//npsdwh.con-way.com:5480/prd_whseview"
#' user_name = "first.last"
#' PW = "name132416"
#' query <- paste("select * from PRD_WHSEVIEW.ADMIN.DM_CUST_MO_SHPMT_ACTVTY limit 10")
#' df <- execute_JDBC_sql(Db_driver, Jdbc_path, JDBC_con, user_name, PW, query)
execute_JDBC_sql <- function(Db_driver ="org.netezza.Driver", Jdbc_path = "C://JDBC//nzjdbc.jar",
                             JDBC_con = "jdbc:netezza//npsdwh.con-way.com:5480/prd_whseview", user_name = "user.name", PW= "name12326", query) {
  drv <- JDBC(driverClass=Db_driver, Jdbc_path)
  JDBC_NZ <- dbConnect(drv, JDBC_con, user_name, PW)
  data <-  dbSendQuery(JDBC_NZ, query)
  df <- fetch(data, n = -1)
  dbDisconnect(JDBC_NZ)
  return(df)
}

