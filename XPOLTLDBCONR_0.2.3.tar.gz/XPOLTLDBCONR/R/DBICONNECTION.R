library(DBI)
library(dbplyr)
library(dplyr)
library(pool)
library(RODBC)
library(RJDBC)


#' Accesses Neteeza database using DBI connection making it easier to access and analyze data with R.
#' Using dplyr, we can easily preview a database and run various analytics and summary statistic. see [website](http://db.rstudio.com/) for more information.
#'
#' @param Driver A program that allows the R and the database to communicate
#' @param Server Inquiry into the database using the SELECT statement
#' @param Database Name of the database to connect to
#' @param UID User name associated with the database
#' @param PWD User password associated with the user ID
#' @param Port Process/application identification number for connection to the DB
#' @return a connection to a specific database
#' @export
#' @examples
#' library(RODBC)
#' con <- DBI_CON(Driver = "NetezzaSQL", Server= "npsdwh", Database = "sandbox", UID=  "user.name", PWD= "password", Port= 5480)
DBI_CON <- function(Driver = "NetezzaSQL", Server= "npsdwh", Database = "sandbox", UID=  "user.name", PWD= "password", Port= 5480) {
  con <- DBI::dbConnect(odbc::odbc(),
                        Driver    = Driver,
                        Server    = Server,
                        Database  = Database,
                        UID       = UID,
                        PWD       = PWD,
                        Port      = 5480)
  return(con)
}


#' Accesses Neteeza database using JDBC connection making it easier to access and analyze data with R.
#' Using dplyr, we can easily preview a database and run various analytics and summary statistics. see [website](http://db.rstudio.com/) for more information.
#'
#' @param Db_driver Loads JDBC driver for desired Database.
#' @param Jdbc_path Path to the driver's JAR file (for shiny server use: "/usr/local/nz/lib/nzjdbc3.jar")
#' @param JDBC_con  Path of the Data Source url including user name and password
#' @return Dataframe with  desired variables and values
#' @export
#' @examples
#' library(RJDBC)
#' con <- DBI_JDBC(Db_driver = "org.netezza.Driver", Jdbc_path = "C://JDBC//nzjdbc.jar", JDBC_con = "jdbc:netezza//npsdwh.con-way.com:5480/prd_whseview;user=user.name;password=password")
DBI_JDBC <- function(Db_driver = "org.netezza.Driver", Jdbc_path = "C://JDBC//nzjdbc.jar",
                     JDBC_con = "jdbc:netezza//npsdwh.con-way.com:5480/prd_whseview;user=user.name;password=pw132216") {
  con <- DBI::dbConnect(JDBC(Db_driver, Jdbc_path),JDBC_con)
  return(con)
}
