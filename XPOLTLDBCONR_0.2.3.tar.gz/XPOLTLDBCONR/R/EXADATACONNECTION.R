library(DBI)
library(pool)
library(RJDBC)

#' Accesses exadata database using JDBC connection
#'
#' @param Db_driver Loads JDBC driver for desired Database.
#' @param Jdbc_path Path to the driver's JAR file (for shiny server use: "/usr/local/nz/lib/nzjdbc3.jar")
#' @param JDBC_con  Path of the Data Source url including user name and password
#' @param userID User ID associated with the Database
#' @param pw  Password associated with user ID
#' @return A connection to a database
#' @export
#' @examples
#' library(pool)
#' library(RJDBC)
#' pool <- exad_JDBC_pool(Db_driver = "oracle.jdbc.OracleDriver", Jdbc_path = "C://oracle//Makubuya.Aaron//product//11.2.0//client_4//jdbc//lib//ojdbc6.jar", JDBC_con = "jdbc:oracle:thin:@//exadata-scan:5721/prdrdr_srv", userID = "username", pw = "password")
#' query <- paste("Select count(*) from rdrview.employee_vw")
#' df <- dbGetQuery(pool, query)
#' poolClose(pool) # Not necessary but can be used in case of leaked pool object.
exad_JDBC_pool <- function(Db_driver = "oracle.jdbc.OracleDriver", Jdbc_path = "C://oracle//john.doe//product//11.2.0//client_4//jdbc//lib//ojdbc6.jar", JDBC_con = "jdbc:oracle:thin:@//exadata-scan:5721/prdrdr_srv", userID = "username", pw = "pw141516") {
  pool <- dbPool(
    drv = JDBC(Db_driver, Jdbc_path),
    url = JDBC_con,
    user = userID,
    password = pw
  )
}
